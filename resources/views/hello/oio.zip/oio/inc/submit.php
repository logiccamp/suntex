<?php 


if (isset($_POST['submit_button'])){
    // getting form variables 
    $username = $_POST['username']; #remember the name of the input
    
    //get the rest of the data
        #here
    // 


    // do something with d data
        #here
    // 

    //start session ; this is to knw the active user
    session_start();
    $_SESSION["loginusername"] = $username;


}